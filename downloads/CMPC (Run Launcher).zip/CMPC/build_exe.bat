@echo off
setlocal
cd /d "%~dp0"
if not exist ".build-env\Scripts\python.exe" py -3 -m venv .build-env
if errorlevel 1 (
    echo Failed to create the isolated build environment.
    pause
    exit /b 1
)
".build-env\Scripts\python.exe" -m pip install -r requirements.txt -r requirements-build.txt
if errorlevel 1 (
    echo Failed to install the executable build dependency.
    pause
    exit /b 1
)
".build-env\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name CMPC app.py
if errorlevel 1 (
    echo Executable build failed.
    pause
    exit /b 1
)
echo Built dist\CMPC.exe
pause
