import threading
import time
import unittest
import queue
import math
import os
import shutil
import sys
import types
from unittest.mock import patch

from app import (
    ApprovedTimeRange,
    ClickerConfig,
    ClickerScheduler,
    INPUT_KEYBOARD,
    KEYEVENTF_KEYUP,
    POINTER_FLAG_DOWN,
    POINTER_FLAG_INCONTACT,
    POINTER_FLAG_INRANGE,
    POINTER_FLAG_UP,
    send_click,
    send_ctrl_tab,
    send_touch_taps,
    OCRMonitor,
    parse_time_range,
    recognize_time_text,
    recognize_time_region,
    recognize_time_image,
    virtual_screen,
)


class TimeFilterTests(unittest.TestCase):
    def test_time_range_parser_requires_exact_valid_24_hour_format(self):
        self.assertEqual(parse_time_range("09:00-09:59"), "09:00-09:59")
        self.assertEqual(parse_time_range("23:59-00:00"), "23:59-00:00")
        self.assertIsNone(parse_time_range("9:00-09:59"))
        self.assertIsNone(parse_time_range("11:30-11:59 extra"))
        self.assertIsNone(parse_time_range("24:00-24:59"))
        self.assertIsNone(parse_time_range("11:60-11:59"))
        self.assertIsNone(recognize_time_text("10:00-10:59", 84.9))
        self.assertIsNone(recognize_time_text("10:00-10:59", math.nan))
        self.assertIsNone(recognize_time_text("10:00-10:59 extra", 99))
        self.assertEqual(recognize_time_text("10:00-10:59", 85), "10:00-10:59")

    def test_monitor_reports_only_exact_configured_ranges_as_approved(self):
        results = queue.Queue()
        outputs = iter([
            ("10:00-10:59", 96),
            ("13:00-13:59", 97),
            ("11:30-11:59", 94),
            (None, 42),
        ])
        monitor = OCRMonitor(results, recognizer=lambda _region: next(outputs))
        configs = [
            ClickerConfig(
                f"id-{index}", f"Clicker {index}", True, 100 + index, 200, 20,
                ocr_region=(10, 10, 100, 30),
                approved_ranges=[
                    ApprovedTimeRange("10:00-10:59"),
                    ApprovedTimeRange("13:00-13:59"),
                ],
            )
            for index in range(4)
        ]
        monitor.start(configs)
        received = []
        deadline = time.monotonic() + 1
        while len(received) < 4 and time.monotonic() < deadline:
            try:
                received.append(results.get(timeout=0.1))
            except queue.Empty:
                pass
        monitor.stop()

        self.assertEqual([item[1][1] for item in received], [
            "APPROVED", "APPROVED", "REJECTED", "UNKNOWN",
        ])

    def test_monitor_updates_when_detected_time_changes_and_fails_closed(self):
        results = queue.Queue()
        samples = iter([
            ("09:00-09:59", 95),
            ("10:00-10:59", 95),
        ])
        monitor = OCRMonitor(results, recognizer=lambda _region: next(samples))
        config = ClickerConfig(
            "one", "One", True, 100, 200, 20,
            ocr_region=(10, 10, 100, 30),
            approved_ranges=[ApprovedTimeRange("09:00-09:59")],
        )
        monitor.start([config])
        first = results.get(timeout=1)
        second = results.get(timeout=1)
        monitor.stop()

        self.assertEqual(first[1][1:3], ("APPROVED", "09:00-09:59"))
        self.assertEqual(second[1][1:3], ("REJECTED", "10:00-10:59"))

        failing_monitor = OCRMonitor(
            results, recognizer=lambda _region: (_ for _ in ()).throw(RuntimeError("OCR failed"))
        )
        failing_monitor.start([config])
        failed = results.get(timeout=1)
        failing_monitor.stop()
        self.assertEqual(failed[1][1], "UNKNOWN")
        self.assertIn("OCR error", failed[1][3])

    def test_region_capture_preprocessing_and_strict_ocr_use_controlled_image(self):
        from PIL import Image

        fake_tesseract = types.SimpleNamespace(
            pytesseract=types.SimpleNamespace(
                tesseract_cmd=r"C:\Program Files\Tesseract-OCR\tesseract.exe"
            ),
            Output=types.SimpleNamespace(DICT="dict"),
            image_to_data=lambda *_args, **_kwargs: {
                "text": ["09:00-09:59"],
                "conf": ["96"],
            },
        )
        sample_image = Image.new("RGB", (120, 32), "white")
        with patch("PIL.ImageGrab.grab", return_value=sample_image) as grab, \
                patch.dict(sys.modules, {"pytesseract": fake_tesseract}), \
                patch("app.os.path.isfile", return_value=True):
            detected, confidence = recognize_time_region((25, 30, 120, 32))

        self.assertEqual(detected, "09:00-09:59")
        self.assertEqual(confidence, 96)
        grab.assert_called_once_with(bbox=(25, 30, 145, 62), all_screens=True)

    @unittest.skipUnless(
        shutil.which("tesseract")
        or os.path.isfile(r"C:\Program Files\Tesseract-OCR\tesseract.exe")
        or os.path.isfile(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        "Tesseract is an optional runtime dependency",
    )
    def test_tesseract_distinguishes_controlled_time_ranges_and_unrelated_text(self):
        from PIL import Image, ImageDraw, ImageFont

        font = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 48)
        samples = {
            "09:00-09:59": "09:00-09:59",
            "10:00-10:59": "10:00-10:59",
            "11:00-11:59": "11:00-11:59",
            "11:30-11:59": "11:30-11:59",
            "Open appointments": None,
        }
        for text, expected in samples.items():
            with self.subTest(text=text):
                image = Image.new("RGB", (480, 100), "white")
                ImageDraw.Draw(image).text((12, 12), text, font=font, fill="black")
                detected, _confidence = recognize_time_image(image)
                self.assertEqual(detected, expected)


class SchedulerTests(unittest.TestCase):
    def test_tab_cycle_sends_two_rounds_before_ctrl_tab(self):
        actions = []
        left, top, _width, _height = virtual_screen()
        scheduler = ClickerScheduler(
            click_action=lambda x, y, _button: actions.append(("click", x, y)),
            tab_action=lambda: actions.append(("tab",)),
        )
        scheduler.start(
            [
                ClickerConfig(
                    f"id-{index}", f"Clicker {index}", True, left + index, top + index,
                    10, click_limit=4,
                )
                for index in range(5)
            ],
            1.0,
            "Mouse",
            cycle_tabs=True,
        )
        deadline = time.monotonic() + 1
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        self.assertFalse(scheduler.snapshot()[0])
        one_round = [("click", left + index, top + index) for index in range(5)]
        self.assertEqual(
            actions,
            one_round + one_round + [("tab",)] + one_round + one_round,
        )

    def test_touch_mode_batches_due_clickers_as_simultaneous_contacts(self):
        batches = []
        left, top, _width, _height = virtual_screen()
        scheduler = ClickerScheduler(
            touch_action=lambda points, hold_ms: batches.append((points, hold_ms))
        )
        scheduler.start(
            [
                ClickerConfig("one", "One", True, left, top, 10, click_limit=1),
                ClickerConfig("two", "Two", True, left + 10, top + 10, 10, click_limit=1),
            ],
            1.0,
            "Touch",
            0,
        )
        deadline = time.monotonic() + 1
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        self.assertFalse(scheduler.snapshot()[0])
        self.assertEqual(batches, [([(left, top), (left + 10, top + 10)], 30)])

    def test_touch_spacing_sends_due_clickers_as_individual_taps(self):
        batches = []
        left, top, _width, _height = virtual_screen()
        scheduler = ClickerScheduler(
            touch_action=lambda points, hold_ms: batches.append(
                (points, hold_ms, time.monotonic())
            )
        )
        scheduler.start(
            [
                ClickerConfig(
                    f"id-{index}", f"Clicker {index}", True, left + index, top + index,
                    10, click_limit=1,
                )
                for index in range(5)
            ],
            1.0,
            "Touch",
            10,
        )
        deadline = time.monotonic() + 2
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        self.assertFalse(scheduler.snapshot()[0])
        self.assertEqual(
            [points for points, _hold_ms, _timestamp in batches],
            [[(left + index, top + index)] for index in range(5)],
        )
        self.assertTrue(all(hold_ms == 30 for _points, hold_ms, _timestamp in batches))
        for (
            (_previous_points, _previous_hold_ms, previous),
            (_points, _hold_ms, current),
        ) in zip(batches, batches[1:]):
            self.assertGreaterEqual(current - previous, 0.008)

    def test_multiple_clickers_have_independent_limits_and_intervals(self):
        calls = []
        lock = threading.Lock()
        errors = __import__("queue").Queue()

        def record_click(x, y, button):
            with lock:
                calls.append((x, y, button, time.monotonic()))

        scheduler = ClickerScheduler(record_click, errors)
        left, top, _width, _height = virtual_screen()
        clickers = [
            ClickerConfig("fast", "Fast", True, left, top, 20, "Left", 3, 0),
            ClickerConfig("slow", "Slow", True, left + 1, top + 1, 60, "Right", 2, 0),
        ]
        scheduler.start(clickers, 1.0)
        deadline = time.monotonic() + 2
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        running, results, _late_count = scheduler.snapshot()
        self.assertFalse(running)
        self.assertEqual(results["fast"]["count"], 3)
        self.assertEqual(results["slow"]["count"], 2)
        self.assertEqual(results["fast"]["status"], "Finished")
        self.assertEqual(results["slow"]["status"], "Finished")
        fast = [call for call in calls if call[2] == "Left"]
        slow = [call for call in calls if call[2] == "Right"]
        self.assertEqual(len(fast), 3)
        self.assertEqual(len(slow), 2)
        self.assertLess(fast[1][3] - fast[0][3], slow[1][3] - slow[0][3])
        self.assertEqual((fast[0][0], fast[0][1]), (left, top))
        self.assertEqual((slow[0][0], slow[0][1]), (left + 1, top + 1))
        self.assertTrue(errors.empty())

    def test_stop_halts_continuous_clicking(self):
        calls = []
        left, top, _width, _height = virtual_screen()
        scheduler = ClickerScheduler(lambda *_args: calls.append(time.monotonic()))
        scheduler.start([ClickerConfig("one", "One", True, left, top, 10)], 1.0)
        time.sleep(0.05)
        scheduler.stop()
        stopped_count = len(calls)
        time.sleep(0.04)
        self.assertGreater(stopped_count, 0)
        self.assertEqual(len(calls), stopped_count)
        self.assertFalse(scheduler.snapshot()[0])

    def test_five_clickers_complete_independently(self):
        calls = []
        lock = threading.Lock()
        errors = queue.Queue()

        def record_click(x, y, button):
            with lock:
                calls.append((x, y, button))

        scheduler = ClickerScheduler(record_click, errors)
        left, top, _width, _height = virtual_screen()
        clickers = [
            ClickerConfig(
                f"id-{index}", f"Clicker {index}", True, left + index, top + index,
                20 + index * 10, ("Left", "Right", "Middle")[index % 3], 2,
            )
            for index in range(5)
        ]
        scheduler.start(clickers, 1.0)
        deadline = time.monotonic() + 2
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        running, results, _late_count = scheduler.snapshot()
        self.assertFalse(running)
        for index in range(5):
            self.assertEqual(results[f"id-{index}"]["count"], 2)
            self.assertEqual(results[f"id-{index}"]["status"], "Finished")
            self.assertEqual(
                sum(call[0] == left + index and call[1] == top + index for call in calls),
                2,
            )
        self.assertTrue(errors.empty())

    def test_input_failure_stops_scheduler_and_reports_error(self):
        errors = queue.Queue()

        def fail_click(*_args):
            raise OSError("simulated input failure")

        left, top, _width, _height = virtual_screen()
        scheduler = ClickerScheduler(fail_click, errors)
        scheduler.start([ClickerConfig("one", "One", True, left, top, 10)], 1.0)
        deadline = time.monotonic() + 1
        while scheduler.snapshot()[0] and time.monotonic() < deadline:
            time.sleep(0.01)

        self.assertFalse(scheduler.snapshot()[0])
        self.assertEqual(errors.get_nowait(), ("error", "simulated input failure"))


class SendClickTests(unittest.TestCase):
    def test_sends_ctrl_tab_with_modifier_releases(self):
        events = []

        def record_input(count, inputs, _size):
            events.extend(
                (inputs[index].type, inputs[index].ki.wVk, inputs[index].ki.dwFlags)
                for index in range(count)
            )
            return count

        with patch("app.user32.SendInput", side_effect=record_input):
            send_ctrl_tab()

        self.assertEqual(events, [
            (INPUT_KEYBOARD, 0x11, 0),
            (INPUT_KEYBOARD, 0x09, 0),
            (INPUT_KEYBOARD, 0x09, KEYEVENTF_KEYUP),
            (INPUT_KEYBOARD, 0x11, KEYEVENTF_KEYUP),
        ])

    def test_positions_cursor_before_sending_button_events(self):
        left, top, _width, _height = virtual_screen()
        calls = []

        def record_input(count, events, _size):
            calls.append(("input", count, [events[index].mi.dwFlags for index in range(count)]))
            return count

        with patch("app.user32.SetCursorPos", side_effect=lambda x, y: calls.append(("move", x, y)) or 1), \
                patch("app.user32.SendInput", side_effect=record_input):
            send_click(left, top, "Left")

        self.assertEqual(calls, [
            ("move", left, top),
            ("input", 2, [0x0002, 0x0004]),
        ])

    def test_releases_button_when_windows_accepts_only_button_down(self):
        left, top, _width, _height = virtual_screen()
        sent_counts = []

        def partial_input(count, _events, _size):
            sent_counts.append(count)
            return 1 if len(sent_counts) == 1 else count

        with patch("app.user32.SetCursorPos", return_value=1), \
                patch("app.user32.SendInput", side_effect=partial_input):
            with self.assertRaisesRegex(OSError, "accepted 1 of 2 button events"):
                send_click(left, top, "Right")

        self.assertEqual(sent_counts, [2, 1])


class SendTouchTests(unittest.TestCase):
    def test_sends_down_and_up_frames_for_every_point(self):
        left, top, _width, _height = virtual_screen()
        frames = []

        def record_frame(count, contacts):
            frames.append([
                (
                    contacts[index].pointerInfo.pointerId,
                    contacts[index].pointerInfo.pointerFlags,
                    contacts[index].pointerInfo.ptPixelLocation.x,
                    contacts[index].pointerInfo.ptPixelLocation.y,
                    contacts[index].pointerInfo.historyCount,
                )
                for index in range(count)
            ])
            return 1

        with patch("app._touch_initialized", False), \
                patch("app.user32.InitializeTouchInjection", return_value=1) as initialize, \
                patch("app.user32.InjectTouchInput", side_effect=record_frame), \
                patch("app.time.sleep") as sleep:
            send_touch_taps([(left, top), (left + 5, top + 5)])

        self.assertEqual(initialize.call_count, 1)
        sleep.assert_called_once_with(0.03)
        self.assertEqual(frames, [
            [
                (1, POINTER_FLAG_INRANGE | POINTER_FLAG_INCONTACT | POINTER_FLAG_DOWN, left, top, 0),
                (2, POINTER_FLAG_INRANGE | POINTER_FLAG_INCONTACT | POINTER_FLAG_DOWN, left + 5, top + 5, 0),
            ],
            [
                (1, POINTER_FLAG_UP, left, top, 0),
                (2, POINTER_FLAG_UP, left + 5, top + 5, 0),
            ],
        ])


if __name__ == "__main__":
    unittest.main()
