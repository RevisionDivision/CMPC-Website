@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show('For help using CMPC, see README.md in this folder.','CMPC')"
if exist "dist\CMPC.exe" (
    start "" "dist\CMPC.exe"
    exit /b 0
)
py -3 app.py
if errorlevel 1 pause
