# CMPC — Caleb's Multi-Point Clicker

CMPC is an experimental Windows application, built by Caleb with the help of AI, for running multiple timed screen-input schedules. It can send mouse clicks or experimental touch taps, cycle through tabs, and passively read on-screen text for configured time ranges.

> **Experimental software:** Touch behavior, timing, and target compatibility may vary. The settings below are a starting point, not guaranteed optimal settings. Test carefully before relying on CMPC.

## At a glance

| Feature | What it does |
| --- | --- |
| Multiple clickers | Runs several independently configured screen positions and schedules |
| Touch input | Sends experimental touch taps instead of moving the mouse cursor |
| Tab cycling | Sends Ctrl+Tab to the foreground application after a round of inputs |
| TIME FILTER | Uses OCR to report whether screen text matches configured time ranges; it does not control clicking |

## Download and launch

1. Download the CMPC ZIP file and extract it. Do not run the app from inside the ZIP.
2. Open the extracted folder and double-click `CMPC.exe`. If the download includes `launch.bat`, you can use that instead.
3. The standalone app does not require Python. The optional **TIME FILTER** OCR feature requires Tesseract OCR; install it if you want to use OCR, or skip that feature.

For running from source or rebuilding the executable, see [Development](#development).

## Quick start

1. Set **Input Mode** to **Touch** (or **Mouse** for ordinary mouse clicks).
2. Open the app and click **Add clicker**.
3. Name the clicker and leave it enabled.
4. Click **Select position**, then click the target location on the screen. Press **Esc** to cancel. The selection click is intercepted and will not click the app underneath.
5. Choose the mouse button and set an interval in milliseconds (minimum **10 ms**). For a first test, use a slower interval such as **1000 ms**.
6. Optionally set a click limit (**0** means unlimited) or an initial delay.
7. Move to a safe test target and press **F8** to start; press it again to stop. You can also use the on-screen toggle or **EMERGENCY STOP**. If another application already uses F8, CMPC reports the conflict; close that application and click **Retry F8**, or use the on-screen toggle.

## Suggested CMPC settings

These are the current experimental settings for the intended workflow. They have not been established as universally optimal; adjust and test them for your screen and target application.

| Setting | Value |
| --- | --- |
| Input Mode | Touch |
| Touch Gap | 30 ms |
| Hold | 15 ms |
| Clickers | 6 total |

Position the six clickers as follows:

1. One on the requested date.
2. One on the drop-down list.
3. One where the time appears.
4. Three on the save button, to improve the chance that the save action registers.

## More options

- **Add clicker:** Create multiple clickers for different positions or schedules. Enable only the clickers you want to run.
- **Save configuration / Load configuration:** Store your settings in a JSON profile and restore them later. Profiles include the input mode, touch gap, hold duration, clickers, and TIME FILTER settings. Older profiles default to Mouse mode, a 25 ms touch gap, and a 30 ms hold.
- **Cycle tabs (Ctrl+Tab):** Sends Ctrl+Tab to the foreground app after two rounds of clicks from every enabled clicker, then repeats. Each clicker's initial delay is honored before the first round; the longest active clicker interval paces later rounds. Click limits still apply. Keep the intended app in the foreground.
- **TIME FILTER:** Enable it, choose a clicker, add exact `HH:MM-HH:MM` ranges, and select that clicker's screen region. It reads text from the region and reports whether it matches configured time ranges. It is informational only: it does not pause, allow, or trigger clicks.
- **EMERGENCY STOP:** Stops all schedules immediately. Closing CMPC also stops the scheduler.

Changes made while clicking is running take effect the next time you start. If clicks are not going where you expect, use **EMERGENCY STOP** and close CMPC when finished.

## Input and timing details

- **Mouse mode** moves the system cursor and sends the selected mouse button.
- **Touch mode** uses Windows touch injection without moving the mouse cursor. Touch contacts are left-contact events, so each clicker's mouse-button setting is ignored. **Touch Gap (ms)** controls spacing between clickers due at the same time: `0` sends them simultaneously; a positive gap sends taps in sequence. **Hold (ms)** sets contact duration (valid range **10–1000 ms**; default **30 ms**).
- Each clicker has its own interval, click limit (**0** means unlimited), and optional initial delay. A global multiplier scales the interval (`configured interval / multiplier`); for example, `2.0x` halves it. The effective interval is clamped to at least **10 ms**.
- **TIME FILTER** checks exact `HH:MM-HH:MM` ranges against OCR text from selected screen regions. Results are **APPROVED**, **REJECTED**, or **UNKNOWN**; only exact full-string matches above the confidence threshold are recognized. It samples asynchronously every 500 ms and reports results only.
- **Select position** uses a translucent overlay that intercepts the selection click, so it is not passed to the underlying application. Press **Esc** to cancel. Coordinates use the Windows virtual desktop, including monitors with negative coordinates.

Intervals are targets, not real-time guarantees. One scheduler thread serves all clickers; Windows scheduling, system load, drivers, and the target application affect delivery. Smaller intervals and many simultaneous clickers are not guaranteed. Touch input may not behave like a physical touchscreen tap: browsers and websites may ignore synthetic touch, interpret it as a gesture, or handle it differently depending on their support. CMPC does not verify that a target is ready or that it accepted an input. OCR can be imperfect, and its status is not connected to the click scheduler.

Input is real system input and may affect the foreground or underlying application. Coordinates are checked against the current virtual screen before starting; a display-layout change that makes a coordinate invalid causes a safe stop. Windows security boundaries can reject input, and CMPC does not attempt to bypass them.

## TL;DR

CMPC is a multi-point clicker made by Caleb with AI assistance. It can run timed clicks or touch taps, cycle tabs, and read screen text for configured times. It is experimental—test it carefully.

For inquiries, contact me on WhatsApp.

*25 November 2026 · 15:30*

## Development (not needed to know, except for OCR)

- Install Python 3.10 or later for Windows with Tcl/Tk. Install dependencies with `py -3 -m pip install -r requirements.txt`, then run `py -3 app.py`.
- To use OCR, install the Tesseract OCR Windows application. The bundled executable includes Pillow and pytesseract but still requires Tesseract installed (on `PATH` or in its standard Program Files location).
- Run tests with `py -3 -m unittest discover -s tests`. Tests mock input and use generated OCR samples; they do not send real mouse or keyboard events.
- The standalone executable is `dist\CMPC.exe`. Rebuild it by double-clicking `build_exe.bat`; the script creates an isolated `.build-env` and installs the app and build dependencies. Internet access is needed for the first build.
