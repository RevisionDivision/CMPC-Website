import ctypes
import json
import math
import os
import queue
import shutil
import sys
import threading
import time
import traceback
import uuid
import re
from dataclasses import asdict, dataclass, field
import tkinter as tk
from tkinter import BooleanVar, StringVar, Tk, Toplevel, filedialog, messagebox, ttk


if sys.platform != "win32":
    raise SystemExit("CMPC is supported on Windows 11.")


user32 = ctypes.WinDLL("user32", use_last_error=True)

SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
KEYEVENTF_KEYUP = 0x0002
VK_CONTROL = 0x11
VK_TAB = 0x09
PT_TOUCH = 2
POINTER_FLAG_INRANGE = 0x00000002
POINTER_FLAG_INCONTACT = 0x00000004
POINTER_FLAG_DOWN = 0x00010000
POINTER_FLAG_UP = 0x00040000
POINTER_FLAG_CANCELED = 0x00080000
TOUCH_MASK_CONTACTAREA = 0x0001
TOUCH_MASK_ORIENTATION = 0x0002
TOUCH_MASK_PRESSURE = 0x0004
TOUCH_FEEDBACK_DEFAULT = 0x1
MAX_TOUCH_COUNT = 256
MOD_NOREPEAT = 0x4000
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
VK_F8 = 0x77
HOTKEY_ID = 1
OCR_CONFIDENCE_MIN = 85
OCR_REFRESH_SECONDS = 0.5
OCR_RESULT_MAX_AGE_SECONDS = 1.5
TIME_RANGE_PATTERN = re.compile(
    r"^\s*(\d{2}):(\d{2})\s*-\s*(\d{2}):(\d{2})\s*$"
)


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", ctypes.c_ulong),
        ("dwFlags", ctypes.c_ulong),
        ("time", ctypes.c_ulong),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", ctypes.c_ushort),
        ("wScan", ctypes.c_ushort),
        ("dwFlags", ctypes.c_uint),
        ("time", ctypes.c_uint),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", ctypes.c_ulong), ("union", INPUTUNION)]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINTER_INFO(ctypes.Structure):
    _fields_ = [
        ("pointerType", ctypes.c_uint),
        ("pointerId", ctypes.c_uint),
        ("frameId", ctypes.c_uint),
        ("pointerFlags", ctypes.c_uint),
        ("sourceDevice", ctypes.c_void_p),
        ("hwndTarget", ctypes.c_void_p),
        ("ptPixelLocation", POINT),
        ("ptHimetricLocation", POINT),
        ("ptPixelLocationRaw", POINT),
        ("ptHimetricLocationRaw", POINT),
        ("dwTime", ctypes.c_uint),
        ("historyCount", ctypes.c_uint),
        ("inputData", ctypes.c_int),
        ("dwKeyStates", ctypes.c_uint),
        ("PerformanceCount", ctypes.c_ulonglong),
        ("ButtonChangeType", ctypes.c_int),
    ]


class POINTER_TOUCH_INFO(ctypes.Structure):
    _fields_ = [
        ("pointerInfo", POINTER_INFO),
        ("touchFlags", ctypes.c_uint),
        ("touchMask", ctypes.c_uint),
        ("rcContact", RECT),
        ("rcContactRaw", RECT),
        ("orientation", ctypes.c_uint),
        ("pressure", ctypes.c_uint),
    ]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", ctypes.c_void_p),
        ("message", ctypes.c_uint),
        ("wParam", ctypes.c_size_t),
        ("lParam", ctypes.c_ssize_t),
        ("time", ctypes.c_ulong),
        ("pt", POINT),
    ]


user32.GetSystemMetrics.argtypes = [ctypes.c_int]
user32.GetSystemMetrics.restype = ctypes.c_int
user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
user32.GetCursorPos.restype = ctypes.c_int
user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
user32.SetCursorPos.restype = ctypes.c_int
user32.SendInput.argtypes = [ctypes.c_uint, ctypes.POINTER(INPUT), ctypes.c_int]
user32.SendInput.restype = ctypes.c_uint
user32.InitializeTouchInjection.argtypes = [ctypes.c_uint, ctypes.c_uint]
user32.InitializeTouchInjection.restype = ctypes.c_int
user32.InjectTouchInput.argtypes = [ctypes.c_uint, ctypes.POINTER(POINTER_TOUCH_INFO)]
user32.InjectTouchInput.restype = ctypes.c_int
user32.RegisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, ctypes.c_uint]
user32.RegisterHotKey.restype = ctypes.c_int
user32.UnregisterHotKey.argtypes = [ctypes.c_void_p, ctypes.c_int]
user32.UnregisterHotKey.restype = ctypes.c_int
user32.GetMessageW.argtypes = [ctypes.POINTER(MSG), ctypes.c_void_p, ctypes.c_uint, ctypes.c_uint]
user32.GetMessageW.restype = ctypes.c_int
user32.PostThreadMessageW.argtypes = [
    ctypes.c_ulong,
    ctypes.c_uint,
    ctypes.c_size_t,
    ctypes.c_ssize_t,
]
user32.PostThreadMessageW.restype = ctypes.c_int
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.GetCurrentThreadId.restype = ctypes.c_ulong
_touch_initialization_lock = threading.Lock()
_touch_initialized = False


def set_dpi_awareness():
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except (AttributeError, OSError):
        try:
            user32.SetProcessDPIAware()
        except AttributeError:
            pass


def virtual_screen():
    left = user32.GetSystemMetrics(SM_XVIRTUALSCREEN)
    top = user32.GetSystemMetrics(SM_YVIRTUALSCREEN)
    width = user32.GetSystemMetrics(SM_CXVIRTUALSCREEN)
    height = user32.GetSystemMetrics(SM_CYVIRTUALSCREEN)
    return left, top, width, height


def _input(flags, x=0, y=0):
    event = INPUT()
    event.type = INPUT_MOUSE
    event.mi = MOUSEINPUT(x, y, 0, flags, 0, 0)
    return event


def send_click(x, y, button):
    left, top, width, height = virtual_screen()
    if width <= 1 or height <= 1 or not (left <= x < left + width and top <= y < top + height):
        raise ValueError(f"Coordinates ({x}, {y}) are outside the current virtual screen.")

    button_flags = {
        "Left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
        "Right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
        "Middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
    }
    down_flag, up_flag = button_flags[button]
    if not user32.SetCursorPos(x, y):
        error = ctypes.get_last_error()
        raise OSError(error, ctypes.FormatError(error))

    events = (INPUT * 2)(_input(down_flag), _input(up_flag))
    sent = user32.SendInput(2, events, ctypes.sizeof(INPUT))
    if sent != 2:
        if sent >= 1:
            release = _input(up_flag)
            user32.SendInput(1, ctypes.byref(release), ctypes.sizeof(INPUT))
        raise OSError(f"Windows accepted {sent} of 2 button events; clicking has been stopped.")


def send_ctrl_tab():
    keys = (INPUT * 4)(
        *(
            INPUT(type=INPUT_KEYBOARD, ki=KEYBDINPUT(key, 0, flags, 0, 0))
            for key, flags in (
                (VK_CONTROL, 0),
                (VK_TAB, 0),
                (VK_TAB, KEYEVENTF_KEYUP),
                (VK_CONTROL, KEYEVENTF_KEYUP),
            )
        )
    )
    sent = user32.SendInput(4, keys, ctypes.sizeof(INPUT))
    if sent != 4:
        releases = (INPUT * 2)(
            INPUT(type=INPUT_KEYBOARD, ki=KEYBDINPUT(VK_TAB, 0, KEYEVENTF_KEYUP, 0, 0)),
            INPUT(type=INPUT_KEYBOARD, ki=KEYBDINPUT(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0, 0)),
        )
        user32.SendInput(2, releases, ctypes.sizeof(INPUT))
        raise OSError(f"Windows accepted {sent} of 4 Ctrl+Tab events; tab cycling has stopped.")


def _touch_contact(pointer_id, x, y, flags):
    contact = POINTER_TOUCH_INFO()
    contact.pointerInfo.pointerType = PT_TOUCH
    contact.pointerInfo.pointerId = pointer_id
    contact.pointerInfo.pointerFlags = flags
    contact.pointerInfo.ptPixelLocation = POINT(x, y)
    contact.touchMask = (
        TOUCH_MASK_CONTACTAREA | TOUCH_MASK_ORIENTATION | TOUCH_MASK_PRESSURE
    )
    contact.rcContact = RECT(x - 2, y - 2, x + 2, y + 2)
    contact.orientation = 0
    contact.pressure = 512
    return contact


def send_touch_taps(points, hold_ms=30):
    points = list(points)
    if not points:
        return
    if not math.isfinite(hold_ms) or not 10 <= hold_ms <= 1000:
        raise ValueError("Touch hold must be a finite number from 10 to 1000 ms.")
    if len(points) > MAX_TOUCH_COUNT:
        raise ValueError(f"Touch mode supports at most {MAX_TOUCH_COUNT} simultaneous contacts.")

    left, top, width, height = virtual_screen()
    if width <= 1 or height <= 1:
        raise ValueError("The current virtual screen dimensions are invalid.")
    for x, y in points:
        if not (left <= x < left + width and top <= y < top + height):
            raise ValueError(f"Coordinates ({x}, {y}) are outside the current virtual screen.")

    global _touch_initialized
    with _touch_initialization_lock:
        if not _touch_initialized:
            if not user32.InitializeTouchInjection(MAX_TOUCH_COUNT, TOUCH_FEEDBACK_DEFAULT):
                error = ctypes.get_last_error()
                raise OSError(
                    error,
                    f"InitializeTouchInjection failed: {ctypes.FormatError(error).strip()}",
                )
            _touch_initialized = True

    down = (POINTER_TOUCH_INFO * len(points))(
        *(
            _touch_contact(
                index + 1,
                x,
                y,
                POINTER_FLAG_INRANGE | POINTER_FLAG_INCONTACT | POINTER_FLAG_DOWN,
            )
            for index, (x, y) in enumerate(points)
        )
    )
    if not user32.InjectTouchInput(len(points), down):
        error = ctypes.get_last_error()
        raise OSError(error, f"Touch-down injection failed: {ctypes.FormatError(error).strip()}")

    time.sleep(hold_ms / 1000)
    up = (POINTER_TOUCH_INFO * len(points))(
        *(
            _touch_contact(index + 1, x, y, POINTER_FLAG_UP)
            for index, (x, y) in enumerate(points)
        )
    )
    if not user32.InjectTouchInput(len(points), up):
        error = ctypes.get_last_error()
        cancelled = (POINTER_TOUCH_INFO * len(points))(
            *(
                _touch_contact(index + 1, x, y, POINTER_FLAG_UP | POINTER_FLAG_CANCELED)
                for index, (x, y) in enumerate(points)
            )
        )
        user32.InjectTouchInput(len(points), cancelled)
        raise OSError(error, f"Touch-up injection failed: {ctypes.FormatError(error).strip()}")


@dataclass
class ApprovedTimeRange:
    value: str
    enabled: bool = True


@dataclass
class ClickerConfig:
    id: str
    name: str
    enabled: bool
    x: int
    y: int
    interval_ms: float
    button: str = "Left"
    click_limit: int = 0
    initial_delay_ms: float = 0
    ocr_region: tuple[int, int, int, int] | None = None
    approved_ranges: list[ApprovedTimeRange] = field(default_factory=list)


def parse_time_range(text):
    if not isinstance(text, str):
        return None
    match = TIME_RANGE_PATTERN.fullmatch(text)
    if match is None:
        return None
    start_hour, start_minute, end_hour, end_minute = map(int, match.groups())
    if (
        start_hour > 23 or start_minute > 59
        or end_hour > 23 or end_minute > 59
    ):
        return None
    return (
        f"{start_hour:02d}:{start_minute:02d}-"
        f"{end_hour:02d}:{end_minute:02d}"
    )


def recognize_time_text(text, confidence):
    if not math.isfinite(confidence) or confidence < OCR_CONFIDENCE_MIN:
        return None
    return parse_time_range(text)


def recognize_time_region(region):
    from PIL import ImageGrab

    left, top, width, height = region
    screenshot = ImageGrab.grab(
        bbox=(left, top, left + width, top + height), all_screens=True
    )
    return recognize_time_image(screenshot)


def recognize_time_image(screenshot):
    from PIL import Image, ImageOps
    import pytesseract

    if not os.path.isfile(pytesseract.pytesseract.tesseract_cmd):
        tesseract_path = shutil.which("tesseract")
        if tesseract_path is None:
            candidates = [
                os.path.join(
                    os.environ.get("ProgramFiles", r"C:\Program Files"),
                    "Tesseract-OCR", "tesseract.exe",
                ),
                os.path.join(
                    os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                    "Tesseract-OCR", "tesseract.exe",
                ),
            ]
            tesseract_path = next(
                (path for path in candidates if os.path.isfile(path)), None
            )
        if tesseract_path is None:
            raise RuntimeError(
                "Tesseract OCR was not found. Install it and ensure tesseract.exe is available."
            )
        pytesseract.pytesseract.tesseract_cmd = tesseract_path

    image = ImageOps.autocontrast(ImageOps.grayscale(screenshot))
    image = image.resize((image.width * 3, image.height * 3), Image.Resampling.LANCZOS)
    image = image.point(lambda pixel: 255 if pixel >= 160 else 0)
    data = pytesseract.image_to_data(
        image,
        config="--psm 7 -c tessedit_char_whitelist=0123456789:-",
        output_type=pytesseract.Output.DICT,
        timeout=1.5,
    )
    words = []
    confidences = []
    for word, raw_confidence in zip(data["text"], data["conf"]):
        word = word.strip()
        try:
            word_confidence = float(raw_confidence)
        except (TypeError, ValueError):
            continue
        if word and word_confidence >= 0:
            words.append(word)
            confidences.append(word_confidence)
    if not words:
        return None, 0.0
    text = " ".join(words)
    confidence = min(confidences)
    return recognize_time_text(text, confidence), confidence


class OCRMonitor:
    def __init__(self, output_queue, recognizer=recognize_time_region):
        self._output_queue = output_queue
        self._recognizer = recognizer
        self._stop_event = threading.Event()
        self._thread = None

    def start(self, configs):
        self.stop()
        self._stop_event = threading.Event()
        self._thread = threading.Thread(
            target=self._run, args=(configs, self._stop_event),
            name="TimeFilterOCR", daemon=True,
        )
        self._thread.start()

    def _run(self, configs, stop_event):
        while not stop_event.is_set():
            scan_started = time.monotonic()
            for config in configs:
                if stop_event.is_set():
                    return
                enabled_ranges = [
                    item.value for item in config.approved_ranges
                    if item.enabled
                ]
                if config.ocr_region is None:
                    self._output_queue.put(
                        ("ocr_result", (
                            config.id, "UNKNOWN", "", "Select an OCR region", time.monotonic()
                        ))
                    )
                    continue
                try:
                    detected, confidence = self._recognizer(config.ocr_region)
                    if detected is None:
                        status, detail = "UNKNOWN", f"Unclear OCR ({confidence:.0f}%)"
                    elif detected in enabled_ranges:
                        status, detail = "APPROVED", f"{detected} ({confidence:.0f}%)"
                    else:
                        status, detail = "REJECTED", f"{detected} ({confidence:.0f}%)"
                except Exception as exc:
                    status, detail, detected = "UNKNOWN", f"OCR error: {exc}", ""
                self._output_queue.put(
                    ("ocr_result", (
                        config.id, status, detected or "", detail, time.monotonic()
                    ))
                )
            stop_event.wait(max(0, OCR_REFRESH_SECONDS - (time.monotonic() - scan_started)))

    def stop(self):
        stop_event = self._stop_event
        thread = self._thread
        if stop_event is not None:
            stop_event.set()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=3)
            if thread.is_alive():
                raise RuntimeError("The OCR monitor did not stop within 3 seconds.")
        self._thread = None


class ClickerScheduler:
    def __init__(
        self, click_action=send_click, error_queue=None, touch_action=send_touch_taps,
        tab_action=send_ctrl_tab,
    ):
        self._click_action = click_action
        self._touch_action = touch_action
        self._tab_action = tab_action
        self._error_queue = error_queue or queue.Queue()
        self._lock = threading.Lock()
        self._stop_event = None
        self._thread = None
        self._results = {}
        self._running = False
        self._late_count = 0
        self._error = None

    def start(
        self, clickers, multiplier, input_mode="Mouse", touch_spacing_ms=0,
        touch_hold_ms=30, cycle_tabs=False,
    ):
        self.stop()
        enabled = [item for item in clickers if item.enabled]
        if not enabled:
            raise ValueError("Enable at least one clicker before starting.")
        if input_mode not in ("Mouse", "Touch"):
            raise ValueError("Choose Mouse or Touch input mode.")
        if not isinstance(cycle_tabs, bool):
            raise ValueError("Tab cycling must be enabled or disabled.")
        if not math.isfinite(touch_spacing_ms) or touch_spacing_ms < 0:
            raise ValueError("Touch spacing must be a finite number of zero or greater.")
        if not math.isfinite(touch_hold_ms) or not 10 <= touch_hold_ms <= 1000:
            raise ValueError("Touch hold must be a finite number from 10 to 1000 ms.")
        if input_mode == "Touch" and len(enabled) > MAX_TOUCH_COUNT:
            raise ValueError(f"Touch mode supports at most {MAX_TOUCH_COUNT} enabled clickers.")

        now = time.monotonic()
        stop_event = threading.Event()
        states = {}
        for item in enabled:
            states[item.id] = {
                "config": item,
                "next_due": now + item.initial_delay_ms / 1000,
                "count": 0,
                "finished": False,
            }
        with self._lock:
            self._stop_event = stop_event
            self._results = {
                item.id: {"count": 0, "status": "Waiting" if item.initial_delay_ms else "Active"}
                for item in enabled
            }
            self._running = True
            self._late_count = 0
            self._error = None
            self._thread = threading.Thread(
                target=self._run,
                args=(
                    states, stop_event, multiplier, input_mode, touch_spacing_ms,
                    touch_hold_ms, cycle_tabs,
                ),
                name="ClickerScheduler"
            )
            self._thread.start()

    def _record_click(self, state, config, interval_s):
        state["count"] += 1
        with self._lock:
            self._results[config.id] = {"count": state["count"], "status": "Active"}

        if config.click_limit and state["count"] >= config.click_limit:
            state["finished"] = True
            with self._lock:
                self._results[config.id]["status"] = "Finished"
        else:
            state["next_due"] = time.monotonic() + interval_s

    def _run(
        self, states, stop_event, multiplier, input_mode, touch_spacing_ms,
        touch_hold_ms, cycle_tabs,
    ):
        try:
            if cycle_tabs:
                self._run_tab_cycles(
                    states, stop_event, multiplier, input_mode, touch_spacing_ms, touch_hold_ms
                )
                return

            while not stop_event.is_set():
                active = [state for state in states.values() if not state["finished"]]
                if not active:
                    break

                now = time.monotonic()
                next_due = min(state["next_due"] for state in active)
                if next_due > now:
                    stop_event.wait(min(next_due - now, 1.0))
                    continue

                due = []
                now = time.monotonic()
                for state in active:
                    if state["next_due"] <= now:
                        config = state["config"]
                        interval_s = max(0.010, config.interval_ms / multiplier / 1000)
                        if now - state["next_due"] > max(0.005, interval_s * 0.25):
                            with self._lock:
                                self._late_count += 1
                        due.append((state, config, interval_s))

                if input_mode == "Touch" and touch_spacing_ms == 0:
                    if due and not stop_event.is_set():
                        self._touch_action(
                            [(config.x, config.y) for _, config, _ in due], touch_hold_ms
                        )
                    for state, config, interval_s in due:
                        if stop_event.is_set():
                            break
                        self._record_click(state, config, interval_s)
                else:
                    for index, (state, config, interval_s) in enumerate(due):
                        if stop_event.is_set():
                            break
                        if input_mode == "Touch":
                            self._touch_action([(config.x, config.y)], touch_hold_ms)
                        else:
                            self._click_action(config.x, config.y, config.button)
                        self._record_click(state, config, interval_s)
                        if (
                            input_mode == "Touch"
                            and touch_spacing_ms > 0
                            and index + 1 < len(due)
                        ):
                            stop_event.wait(touch_spacing_ms / 1000)
        except Exception as exc:
            with self._lock:
                self._error = str(exc)
            stop_event.set()
            self._error_queue.put(("error", str(exc)))
        finally:
            with self._lock:
                self._running = False
                if stop_event.is_set():
                    for result in self._results.values():
                        if result["status"] in ("Active", "Waiting"):
                            result["status"] = "Stopped"

    def _run_tab_cycles(
        self, states, stop_event, multiplier, input_mode, touch_spacing_ms, touch_hold_ms
    ):
        rounds_since_tab = 0
        while not stop_event.is_set():
            active = [state for state in states.values() if not state["finished"]]
            if not active:
                return

            round_due = max(state["next_due"] for state in active)
            delay = round_due - time.monotonic()
            if delay > 0 and stop_event.wait(delay):
                return

            active = [state for state in states.values() if not state["finished"]]
            round_clickers = [
                (state, state["config"], max(0.010, state["config"].interval_ms / multiplier / 1000))
                for state in active
            ]
            if input_mode == "Touch" and touch_spacing_ms == 0:
                if not stop_event.is_set():
                    self._touch_action(
                        [(config.x, config.y) for _, config, _ in round_clickers], touch_hold_ms
                    )
                for state, config, interval_s in round_clickers:
                    if stop_event.is_set():
                        return
                    self._record_click(state, config, interval_s)
            else:
                for index, (state, config, interval_s) in enumerate(round_clickers):
                    if stop_event.is_set():
                        return
                    if input_mode == "Touch":
                        self._touch_action([(config.x, config.y)], touch_hold_ms)
                    else:
                        self._click_action(config.x, config.y, config.button)
                    self._record_click(state, config, interval_s)
                    if (
                        input_mode == "Touch"
                        and touch_spacing_ms > 0
                        and index + 1 < len(round_clickers)
                    ):
                        if stop_event.wait(touch_spacing_ms / 1000):
                            return
            active = [state for state in states.values() if not state["finished"]]
            if not active or stop_event.is_set():
                return
                return
            rounds_since_tab += 1
            if rounds_since_tab == 2:
                self._tab_action()
                rounds_since_tab = 0

    def stop(self):
        with self._lock:
            stop_event = self._stop_event
            thread = self._thread
        if stop_event is not None:
            stop_event.set()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=2)
            if thread.is_alive():
                raise RuntimeError("The click scheduler did not stop within 2 seconds.")
        with self._lock:
            self._running = False
            self._thread = None
            self._stop_event = None

    def snapshot(self):
        with self._lock:
            return self._running, {key: value.copy() for key, value in self._results.items()}, self._late_count


class HotkeyListener(threading.Thread):
    def __init__(self, event_queue):
        super().__init__(name="GlobalHotkey", daemon=False)
        self._events = event_queue
        self._thread_id = None
        self._ready = threading.Event()

    def run(self):
        self._thread_id = kernel32.GetCurrentThreadId()
        if not user32.RegisterHotKey(None, HOTKEY_ID, MOD_NOREPEAT, VK_F8):
            self._events.put(("hotkey_error", ctypes.WinError(ctypes.get_last_error()).strerror))
            self._ready.set()
            return
        self._events.put(("hotkey_ready", None))
        self._ready.set()
        message = MSG()
        try:
            while True:
                result = user32.GetMessageW(ctypes.byref(message), None, 0, 0)
                if result == -1:
                    self._events.put(
                        ("hotkey_error", ctypes.WinError(ctypes.get_last_error()).strerror)
                    )
                    break
                if result == 0:
                    break
                if message.message == WM_HOTKEY and message.wParam == HOTKEY_ID:
                    self._events.put(("toggle", None))
        finally:
            user32.UnregisterHotKey(None, HOTKEY_ID)

    def close(self):
        self._ready.wait(timeout=1)
        if self.is_alive() and self._thread_id:
            user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
            self.join(timeout=2)


def new_config(name="Clicker 1"):
    left, top, width, height = virtual_screen()
    return ClickerConfig(uuid.uuid4().hex, name, True, left + width // 2, top + height // 2, 100)


class ClickerRow:
    def __init__(self, app, config):
        self.app = app
        self.config_id = config.id
        self.frame = ttk.LabelFrame(
            app.clicker_frame, text=f"  {config.name}  ", padding=(14, 12),
            style="Card.TLabelframe",
        )
        self.name = StringVar(value=config.name)
        self.enabled = BooleanVar(value=config.enabled)
        self.x = StringVar(value=str(config.x))
        self.y = StringVar(value=str(config.y))
        self.interval = StringVar(value=str(config.interval_ms))
        self.button = StringVar(value=config.button)
        self.limit = StringVar(value=str(config.click_limit))
        self.delay = StringVar(value=str(config.initial_delay_ms))
        self.ocr_region = config.ocr_region
        self.ocr_region_text = StringVar(value=self._format_ocr_region())
        self.approved_ranges = config.approved_ranges
        self.status = StringVar(value="Disabled" if not config.enabled else "Ready")
        self.count = StringVar(value="0 clicks")

        for column, weight in enumerate((3, 1, 1, 2)):
            self.frame.columnconfigure(column, weight=weight, uniform="clicker-fields")

        def add_field(label, variable, row, column, width=12, choices=None):
            ttk.Label(self.frame, text=label, style="FieldLabel.TLabel").grid(
                row=row, column=column, sticky="w", padx=5, pady=(3, 2)
            )
            if choices is not None:
                widget = ttk.Combobox(
                    self.frame, textvariable=variable, values=choices,
                    state="readonly", width=width,
                )
            else:
                widget = ttk.Entry(self.frame, textvariable=variable, width=width)
            widget.grid(row=row + 1, column=column, sticky="ew", padx=5, pady=(0, 7))

        add_field("CLICKER NAME", self.name, 0, 0, 20)
        add_field("SCREEN X", self.x, 0, 1, 9)
        add_field("SCREEN Y", self.y, 0, 2, 9)
        add_field("INTERVAL · MS", self.interval, 0, 3, 12)
        add_field("MOUSE BUTTON", self.button, 2, 0, 12, ("Left", "Right", "Middle"))
        add_field("CLICK LIMIT · 0 = ∞", self.limit, 2, 1, 12)
        add_field("INITIAL DELAY · MS", self.delay, 2, 2, 12)

        actions = ttk.Frame(self.frame, style="Card.TFrame")
        actions.grid(row=4, column=0, columnspan=4, sticky="ew", padx=3, pady=(2, 3))
        ttk.Checkbutton(actions, text="Enabled", variable=self.enabled).pack(side="left", padx=(2, 12))
        ttk.Button(
            actions, text="Pick click point", style="Accent.TButton",
            command=lambda: app.select_position(self),
        ).pack(side="left", padx=3)
        ttk.Button(
            actions, text="Pick OCR area",
            command=lambda: app.select_ocr_region(self),
        ).pack(side="left", padx=3)
        ttk.Label(actions, textvariable=self.status, style="Status.TLabel").pack(side="left", padx=(12, 4))
        ttk.Label(actions, textvariable=self.count, style="Muted.TLabel").pack(side="left", padx=4)
        ttk.Button(
            actions, text="Remove", style="Danger.TButton",
            command=lambda: app.remove_clicker(self),
        ).pack(side="right", padx=3)
        ttk.Label(
            self.frame, textvariable=self.ocr_region_text, style="Muted.TLabel"
        ).grid(row=5, column=0, columnspan=4, sticky="w", padx=8, pady=(2, 0))

    def _format_ocr_region(self):
        if self.ocr_region is None:
            return "OCR region not selected"
        left, top, width, height = self.ocr_region
        return f"OCR area: {left},{top}  {width}×{height}"

    def config(self):
        name = self.name.get().strip()
        if not name:
            raise ValueError("Clicker names cannot be empty.")
        x = int(self.x.get())
        y = int(self.y.get())
        interval = float(self.interval.get())
        limit = int(self.limit.get())
        delay = float(self.delay.get())
        if not math.isfinite(interval) or interval < 10:
            raise ValueError(f"{name}: interval must be at least 10 ms.")
        if limit < 0:
            raise ValueError(f"{name}: click limit must be zero or greater.")
        if not math.isfinite(delay) or delay < 0:
            raise ValueError(f"{name}: initial delay cannot be negative.")
        if self.button.get() not in ("Left", "Right", "Middle"):
            raise ValueError(f"{name}: choose Left, Right, or Middle mouse button.")
        return ClickerConfig(
            self.config_id, name, self.enabled.get(), x, y, interval, self.button.get(),
            limit, delay, self.ocr_region,
            [ApprovedTimeRange(item.value, item.enabled) for item in self.approved_ranges],
        )

    def set_ocr_region(self, region):
        self.ocr_region = region
        self.ocr_region_text.set(self._format_ocr_region())

    def update_status(self, result):
        if result is None:
            self.status.set("Disabled" if not self.enabled.get() else "Ready")
            self.count.set("0 clicks")
        else:
            self.status.set(result["status"])
            self.count.set(f'{result["count"]} clicks')

class ClickerApp:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.scheduler = ClickerScheduler(error_queue=self.events)
        self.ocr_monitor = OCRMonitor(self.events)
        self.rows = []
        self.overlay = None
        self.region_overlay = None
        self.selected_row = None
        self.selected_region_row = None
        self.ocr_results = {}
        self._closed = False
        self.hotkey_listener = HotkeyListener(self.events)
        self.hotkey_state = StringVar(value="F8: registering...")
        self.status = StringVar(value="STOPPED")
        self.summary = StringVar(value="0 enabled / 0 configured")
        self.multiplier = StringVar(value="1.0")
        self.cycle_tabs = BooleanVar(value=False)
        self.input_mode = StringVar(value="Mouse")
        self.touch_spacing = StringVar(value="25")
        self.touch_hold = StringVar(value="30")
        self.time_filter_enabled = BooleanVar(value=False)
        self.time_filter_clicker = StringVar()
        self.time_range_entry = StringVar()
        self.gui_size = StringVar(value="Medium")
        self._ui_scale_factor = 1.0
        self._ui_widget_metrics = {}
        self.timing = StringVar(value="Timing: Windows scheduling is best-effort; minimum interval is 10 ms.")

        root.title("Caleb's Multi Point Clicker")
        root.geometry("1180x860")
        root.minsize(980, 680)
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.report_callback_exception = self.report_callback_exception

        style = ttk.Style(root)
        try:
            style.theme_use("clam")
        except Exception:
            pass

        background = "#0B1220"
        panel = "#111D2E"
        surface = "#18283D"
        foreground = "#E6EEF8"
        muted = "#9AABC0"
        accent = "#38BDF8"
        style.configure(".", font=("Segoe UI", 10), background=background, foreground=foreground)
        style.configure("TFrame", background=background)
        style.configure("Card.TFrame", background=panel)
        style.configure("TLabel", background=background, foreground=foreground)
        style.configure("Muted.TLabel", foreground=muted)
        style.configure("FieldLabel.TLabel", foreground=muted, font=("Segoe UI", 8, "bold"))
        style.configure("Status.TLabel", foreground="#5EEAD4", font=("Segoe UI", 10, "bold"))
        style.configure("TButton", background=surface, foreground=foreground, padding=(11, 7), borderwidth=0)
        style.map("TButton", background=[("active", "#263B55"), ("disabled", "#202B39")])
        style.configure("Accent.TButton", background=accent, foreground="#07111C", font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#7DD3FC")])
        style.configure("Danger.TButton", background="#492331", foreground="#FDA4AF")
        style.map("Danger.TButton", background=[("active", "#673044")])
        style.configure("TCheckbutton", background=background, foreground=foreground)
        style.map("TCheckbutton", background=[("active", background)])
        style.configure("TEntry", fieldbackground=surface, foreground=foreground, insertcolor=foreground, padding=6)
        style.configure(
            "TCombobox", fieldbackground=surface, background=surface,
            foreground=foreground, selectbackground=surface,
            selectforeground=foreground, arrowcolor=foreground, padding=5,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", surface), ("disabled", panel)],
            foreground=[("readonly", foreground), ("disabled", muted)],
            selectbackground=[("readonly", surface)],
            selectforeground=[("readonly", foreground)],
        )
        style.configure("TNotebook", background=background, borderwidth=0)
        style.configure("TNotebook.Tab", background=surface, foreground=muted, padding=(18, 10), font=("Segoe UI", 10, "bold"))
        style.map("TNotebook.Tab", background=[("selected", panel)], foreground=[("selected", accent)])
        style.configure("Card.TLabelframe", background=panel, bordercolor="#26364B", relief="solid")
        style.configure("Card.TLabelframe.Label", background=panel, foreground=accent, font=("Segoe UI", 10, "bold"))
        style.configure("TLabelframe", background=background, bordercolor="#26364B")
        style.configure("TLabelframe.Label", background=background, foreground=accent, font=("Segoe UI", 10, "bold"))
        style.configure(
            "Treeview", background=panel, fieldbackground=panel, foreground=foreground,
            rowheight=30, borderwidth=0,
        )
        style.configure("Treeview.Heading", background=surface, foreground=muted, font=("Segoe UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#164E63")], foreground=[("selected", "#ECFEFF")])

        root.configure(background=background)
        header = tk.Frame(root, bg="#0F1B2B", padx=22, pady=16)
        header.pack(fill="x")
        identity = tk.Frame(header, bg="#0F1B2B")
        identity.pack(side="left", fill="x", expand=True)
        tk.Label(
            identity, text="CMPC  /  CONTROL CENTER", bg="#0F1B2B", fg=accent,
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w")
        tk.Label(
            identity, text="Caleb's Multi Point Clicker", bg="#0F1B2B", fg=foreground,
            font=("Segoe UI", 21, "bold"),
        ).pack(anchor="w", pady=(2, 0))
        ttk.Label(header, textvariable=self.status, style="Status.TLabel").pack(side="right", padx=12)

        controls = ttk.Frame(root, padding=(18, 12))
        controls.pack(fill="x")
        ttk.Button(
            controls, text="START / STOP  ·  F8", style="Accent.TButton", command=self.toggle
        ).pack(side="left", padx=(0, 7))
        ttk.Button(controls, text="EMERGENCY STOP", style="Danger.TButton", command=self.stop).pack(
            side="left", padx=4
        )
        ttk.Label(controls, textvariable=self.hotkey_state, style="Muted.TLabel").pack(
            side="left", padx=(12, 3)
        )
        ttk.Button(controls, text="Retry F8", command=self.retry_hotkey).pack(side="left", padx=3)
        ttk.Separator(controls, orient="vertical").pack(side="left", fill="y", padx=12)
        ttk.Label(controls, text="Speed").pack(side="left", padx=(0, 5))
        ttk.Entry(controls, textvariable=self.multiplier, width=7).pack(side="left")
        ttk.Label(controls, text="×   2× = twice as fast", style="Muted.TLabel").pack(side="left", padx=6)
        ttk.Checkbutton(controls, text="Cycle tabs (Ctrl+Tab)", variable=self.cycle_tabs).pack(
            side="left", padx=13
        )
        ttk.Label(controls, textvariable=self.summary, style="Muted.TLabel").pack(side="right", padx=3)

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=18, pady=(0, 8))
        clickers_page = ttk.Frame(notebook, padding=14)
        time_page = ttk.Frame(notebook, padding=14)
        notebook.add(clickers_page, text="  CLICKERS  ")
        notebook.add(time_page, text="  TIME FILTER  ")

        toolbar = ttk.Frame(clickers_page, padding=(0, 0, 0, 10))
        toolbar.pack(fill="x")
        ttk.Button(toolbar, text="+ Add clicker", style="Accent.TButton", command=self.add_clicker).pack(
            side="left", padx=(0, 6)
        )
        ttk.Button(toolbar, text="Save configuration…", command=self.save_config).pack(side="left", padx=3)
        ttk.Button(toolbar, text="Load configuration…", command=self.load_config).pack(side="left", padx=3)
        ttk.Label(toolbar, text="Input mode", style="FieldLabel.TLabel").pack(side="left", padx=(20, 6))
        ttk.Combobox(
            toolbar, textvariable=self.input_mode, values=("Mouse", "Touch"),
            state="readonly", width=9,
        ).pack(side="left")
        ttk.Label(toolbar, text="Touch gap · ms", style="FieldLabel.TLabel").pack(side="left", padx=(12, 5))
        ttk.Entry(toolbar, textvariable=self.touch_spacing, width=6).pack(side="left")
        ttk.Label(toolbar, text="Hold · ms", style="FieldLabel.TLabel").pack(side="left", padx=(10, 5))
        ttk.Entry(toolbar, textvariable=self.touch_hold, width=6).pack(side="left")

        container = ttk.Frame(clickers_page, style="Card.TFrame", padding=(12, 8))
        container.pack(fill="both", expand=True)
        ttk.Label(container, text="CLICKER SCHEDULES", style="FieldLabel.TLabel").pack(
            anchor="w", padx=4, pady=(0, 6)
        )
        canvas = tk.Canvas(container, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.clicker_frame = ttk.Frame(canvas, style="Card.TFrame")
        self.clicker_frame.bind(
            "<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        clicker_window = canvas.create_window((0, 0), window=self.clicker_frame, anchor="nw")
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(clicker_window, width=event.width))
        canvas.configure(background=panel)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.canvas = canvas

        ttk.Label(
            time_page,
            text="Monitor screen text for each clicker. This OCR panel is informational only; it does not permit, block, or trigger clicks.",
            style="Muted.TLabel", wraplength=1000,
        ).pack(anchor="w", pady=(0, 12))
        filter_options = ttk.LabelFrame(time_page, text=" MONITOR SETTINGS ", padding=12)
        filter_options.pack(fill="x", pady=(0, 10))
        filter_row = ttk.Frame(filter_options)
        filter_row.pack(fill="x")
        ttk.Checkbutton(
            filter_row, text="Enable passive OCR monitor", variable=self.time_filter_enabled,
        ).pack(side="left", padx=(2, 18))
        ttk.Label(filter_row, text="Configure ranges for", style="FieldLabel.TLabel").pack(side="left", padx=(0, 7))
        self.time_filter_selector = ttk.Combobox(
            filter_row, textvariable=self.time_filter_clicker, state="readonly", width=28
        )
        self.time_filter_selector.pack(side="left")
        self.time_filter_selector.bind("<<ComboboxSelected>>", self.refresh_time_ranges)

        range_area = ttk.Frame(time_page)
        range_area.pack(fill="both", expand=True)
        range_panel = ttk.LabelFrame(range_area, text=" APPROVED TIME RANGES ", padding=12)
        range_panel.pack(side="left", fill="both", expand=True, padx=(0, 7))
        ttk.Label(range_panel, text="Enter exact 24-hour ranges in HH:MM-HH:MM format.", style="Muted.TLabel").pack(
            anchor="w", pady=(0, 8)
        )
        range_editor = ttk.Frame(range_panel)
        range_editor.pack(fill="x", pady=(0, 8))
        ttk.Entry(range_editor, textvariable=self.time_range_entry, width=18).pack(side="left")
        ttk.Button(range_editor, text="Add / update", style="Accent.TButton", command=self.add_time_range).pack(
            side="left", padx=(6, 3)
        )
        ttk.Button(range_editor, text="Enable / disable", command=self.toggle_time_range).pack(
            side="left", padx=3
        )
        ttk.Button(range_editor, text="Remove", style="Danger.TButton", command=self.remove_time_range).pack(
            side="left", padx=3
        )
        list_holder = ttk.Frame(range_panel, style="Card.TFrame")
        list_holder.pack(fill="both", expand=True)
        self.time_ranges_list = tk.Listbox(
            list_holder, height=8, exportselection=False, relief="flat",
            background=surface, foreground=foreground, selectbackground="#164E63",
            selectforeground="#ECFEFF", highlightthickness=0, font=("Consolas", 11),
        )
        range_scroll = ttk.Scrollbar(list_holder, orient="vertical", command=self.time_ranges_list.yview)
        self.time_ranges_list.configure(yscrollcommand=range_scroll.set)
        self.time_ranges_list.pack(side="left", fill="both", expand=True)
        range_scroll.pack(side="right", fill="y")
        self.time_ranges_list.bind("<<ListboxSelect>>", self.select_time_range)

        status_panel = ttk.LabelFrame(range_area, text=" LIVE OCR STATUS ", padding=12)
        status_panel.pack(side="left", fill="both", expand=True, padx=(7, 0))
        ttk.Label(
            status_panel, text="Each clicker has its own selected screen region.",
            style="Muted.TLabel",
        ).pack(anchor="w", pady=(0, 8))
        self.ocr_status_tree = ttk.Treeview(
            status_panel, columns=("clicker", "time", "status", "detail"),
            show="headings", height=10,
        )
        for column, heading, width in (
            ("clicker", "CLICKER", 125), ("time", "DETECTED TIME", 125),
            ("status", "STATUS", 100), ("detail", "RECOGNITION", 230),
        ):
            self.ocr_status_tree.heading(column, text=heading)
            self.ocr_status_tree.column(column, width=width, stretch=column == "detail")
        self.ocr_status_tree.tag_configure("approved", foreground="#5EEAD4")
        self.ocr_status_tree.tag_configure("rejected", foreground="#FDA4AF")
        self.ocr_status_tree.tag_configure("unknown", foreground="#FBBF24")
        self.ocr_status_tree.pack(fill="both", expand=True)

        footer = ttk.Frame(root, padding=(20, 4, 20, 12))
        footer.pack(fill="x")
        ttk.Label(footer, textvariable=self.timing, style="Muted.TLabel", wraplength=1050).pack(
            side="left", anchor="w", fill="x", expand=True
        )
        ttk.Label(footer, text="GUI SIZE", style="FieldLabel.TLabel").pack(side="left", padx=(12, 6))
        ttk.Combobox(
            footer, textvariable=self.gui_size, values=("Small", "Medium", "Large"),
            state="readonly", width=9,
        ).pack(side="left")
        self.gui_size.trace_add("write", self.apply_gui_size)

        self.add_clicker(new_config())
        self.refresh_time_filter_clickers()
        self.hotkey_listener.start()
        self.root.after(50, self.poll)

    def apply_gui_size(self, *_args):
        sizes = {
            "Small": ("1000x740", (920, 660), 0.82),
            "Medium": ("1180x860", (980, 680), 1.0),
            "Large": ("1400x980", (1100, 780), 1.2),
        }
        geometry, minimum, scale = sizes[self.gui_size.get()]
        self.root.minsize(*minimum)
        self.root.tk.call("tk", "scaling", scale)
        self._ui_scale_factor = scale
        style = ttk.Style(self.root)
        style.configure("TButton", padding=self._scale_metric((11, 7), scale))
        style.configure("TEntry", padding=self._scale_metric(6, scale))
        style.configure("TCombobox", padding=self._scale_metric(5, scale))
        style.configure("TNotebook.Tab", padding=self._scale_metric((18, 10), scale))
        style.configure("Treeview", rowheight=round(30 * scale))
        self._scale_widget_tree(self.root, scale)
        self.root.geometry(geometry)

    @staticmethod
    def _scale_metric(value, factor):
        if isinstance(value, (tuple, list)):
            return tuple(ClickerApp._scale_metric(item, factor) for item in value)
        if isinstance(value, (int, float)):
            return round(value * factor)
        if isinstance(value, str):
            parts = value.split()
            if parts and all(part.lstrip("-").isdigit() for part in parts):
                scaled = tuple(round(int(part) * factor) for part in parts)
                return scaled[0] if len(scaled) == 1 else scaled
        return value

    def _scale_widget_tree(self, widget, factor):
        metrics = self._ui_widget_metrics.get(widget)
        if metrics is None:
            metrics = {"options": {}, "geometry": {}}
            for option in ("padding", "padx", "pady", "highlightthickness", "borderwidth"):
                if option in widget.keys():
                    try:
                        value = widget.cget(option)
                    except tk.TclError:
                        continue
                    if value not in ("", None):
                        metrics["options"][option] = value
            for manager in ("pack", "grid", "place"):
                try:
                    info = getattr(widget, f"{manager}_info")()
                except (tk.TclError, AttributeError):
                    continue
                if info:
                    metrics["geometry"][manager] = {
                        key: info[key] for key in ("padx", "pady", "ipadx", "ipady")
                        if key in info
                    }
            self._ui_widget_metrics[widget] = metrics

        for option, value in metrics["options"].items():
            try:
                widget.configure(**{option: self._scale_metric(value, factor)})
            except tk.TclError:
                continue
        for manager, options in metrics["geometry"].items():
            scaled = {key: self._scale_metric(value, factor) for key, value in options.items()}
            try:
                getattr(widget, f"{manager}_configure")(**scaled)
            except (tk.TclError, AttributeError):
                continue
        for child in widget.winfo_children():
            self._scale_widget_tree(child, factor)

    def retry_hotkey(self):
        if self.hotkey_listener.is_alive():
            return
        self.hotkey_state.set("F8: registering...")
        self.hotkey_listener = HotkeyListener(self.events)
        self.hotkey_listener.start()

    def update_summary(self):
        enabled = sum(1 for row in self.rows if row.enabled.get())
        self.summary.set(f"{enabled} enabled / {len(self.rows)} configured")

    def add_clicker(self, config=None):
        if config is None:
            config = new_config(f"Clicker {len(self.rows) + 1}")
        row = ClickerRow(self, config)
        row.frame.pack(fill="x", expand=True, pady=4)
        if self._ui_scale_factor != 1.0:
            self._scale_widget_tree(row.frame, self._ui_scale_factor)
        self.rows.append(row)
        row.enabled.trace_add("write", lambda *_args: self.update_summary())
        row.name.trace_add("write", lambda *_args, item=row: self._clicker_name_changed(item))
        self.ocr_status_tree.insert(
            "", "end", iid=row.config_id,
            values=(row.name.get(), "—", "UNKNOWN", "Not monitoring"), tags=("unknown",),
        )
        self.update_summary()
        self.refresh_time_filter_clickers()

    def _clicker_name_changed(self, row):
        row.frame.configure(text=f"  {row.name.get()}  ")
        self.refresh_time_filter_clickers()

    def remove_clicker(self, row):
        if self.status.get() == "RUNNING":
            messagebox.showwarning("Stop first", "Stop all clickers before removing one.", parent=self.root)
            return
        row.frame.destroy()
        self.rows.remove(row)
        if self.ocr_status_tree.exists(row.config_id):
            self.ocr_status_tree.delete(row.config_id)
        self.update_summary()
        self.refresh_time_filter_clickers()

    def refresh_time_filter_clickers(self):
        labels = []
        self._time_filter_rows = {}
        for row in self.rows:
            label = f"{row.name.get()} [{row.config_id[:6]}]"
            labels.append(label)
            self._time_filter_rows[label] = row
        current = self.time_filter_clicker.get()
        self.time_filter_selector.configure(values=labels)
        if current not in self._time_filter_rows and labels:
            self.time_filter_clicker.set(labels[0])
        elif not labels:
            self.time_filter_clicker.set("")
        self.refresh_time_ranges()

    def _selected_time_filter_row(self):
        return self._time_filter_rows.get(self.time_filter_clicker.get())

    def refresh_time_ranges(self, _event=None):
        if not hasattr(self, "time_ranges_list"):
            return
        self.time_ranges_list.delete(0, "end")
        row = self._selected_time_filter_row()
        if row is None:
            return
        for item in row.approved_ranges:
            marker = "✓" if item.enabled else " "
            self.time_ranges_list.insert("end", f"[{marker}] {item.value}")

    def select_time_range(self, _event=None):
        row = self._selected_time_filter_row()
        selection = self.time_ranges_list.curselection()
        if row is not None and selection:
            self.time_range_entry.set(row.approved_ranges[selection[0]].value)

    def add_time_range(self):
        row = self._selected_time_filter_row()
        value = parse_time_range(self.time_range_entry.get())
        if row is None:
            messagebox.showwarning("Select a clicker", "Choose a clicker first.", parent=self.root)
            return
        if value is None:
            messagebox.showerror(
                "Invalid time range",
                "Enter a valid range in HH:MM-HH:MM format, for example 09:00-09:59.",
                parent=self.root,
            )
            return
        selection = self.time_ranges_list.curselection()
        if selection:
            row.approved_ranges[selection[0]].value = value
        elif not any(item.value == value for item in row.approved_ranges):
            row.approved_ranges.append(ApprovedTimeRange(value))
        self.time_range_entry.set("")
        self.refresh_time_ranges()

    def toggle_time_range(self):
        row = self._selected_time_filter_row()
        selection = self.time_ranges_list.curselection()
        if row is None or not selection:
            return
        item = row.approved_ranges[selection[0]]
        item.enabled = not item.enabled
        self.refresh_time_ranges()
        self.time_ranges_list.selection_set(selection[0])

    def remove_time_range(self):
        row = self._selected_time_filter_row()
        selection = self.time_ranges_list.curselection()
        if row is None or not selection:
            return
        del row.approved_ranges[selection[0]]
        self.refresh_time_ranges()

    def select_ocr_region(self, row):
        if self.region_overlay is not None or self.overlay is not None:
            return
        self.selected_region_row = row
        left, top, width, height = virtual_screen()
        overlay = Toplevel(self.root)
        overlay.overrideredirect(True)
        overlay.attributes("-topmost", True)
        overlay.attributes("-alpha", 0.30)
        overlay.geometry(f"{width}x{height}+{left}+{top}")
        overlay.configure(background="#18324a")
        canvas = tk.Canvas(overlay, highlightthickness=0, cursor="crosshair")
        canvas.pack(fill="both", expand=True)
        label = ttk.Label(
            overlay,
            text=f"Drag around the displayed time for {row.name.get()}  ·  Esc to cancel",
            font=("Segoe UI", 18, "bold"),
            padding=20,
        )
        label.place(relx=0.5, rely=0.04, anchor="n")
        self.region_overlay = overlay
        self._ocr_selection_start = None
        self._ocr_selection_rect = None

        def begin(event):
            self._ocr_selection_start = (event.x, event.y, event.x_root, event.y_root)
            self._ocr_selection_rect = canvas.create_rectangle(
                event.x, event.y, event.x, event.y, outline="#ff3030", width=3
            )

        def update(event):
            if self._ocr_selection_rect is not None:
                x, y = self._ocr_selection_start[:2]
                canvas.coords(self._ocr_selection_rect, x, y, event.x, event.y)

        def finish(event):
            if self._ocr_selection_start is None:
                return
            _x, _y, start_x, start_y = self._ocr_selection_start
            region = (
                min(start_x, event.x_root),
                min(start_y, event.y_root),
                abs(event.x_root - start_x),
                abs(event.y_root - start_y),
            )
            if region[2] < 10 or region[3] < 10:
                messagebox.showwarning(
                    "OCR region too small", "Select an area at least 10 by 10 pixels.",
                    parent=self.root,
                )
                self.cancel_ocr_region()
                return
            self.selected_region_row.set_ocr_region(region)
            self.cancel_ocr_region()

        canvas.bind("<ButtonPress-1>", begin)
        canvas.bind("<B1-Motion>", update)
        canvas.bind("<ButtonRelease-1>", finish)
        overlay.bind("<Escape>", lambda _event: self.cancel_ocr_region())
        overlay.focus_force()

    def cancel_ocr_region(self):
        if self.region_overlay is not None:
            self.region_overlay.destroy()
        self.region_overlay = None
        self.selected_region_row = None

    def collect_configs(self):
        configs = [row.config() for row in self.rows]
        left, top, width, height = virtual_screen()
        for config in configs:
            if config.enabled and not (
                left <= config.x < left + width and top <= config.y < top + height
            ):
                raise ValueError(
                    f"{config.name}: ({config.x}, {config.y}) is outside the current screen "
                    f"bounds ({left}..{left + width - 1}, {top}..{top + height - 1})."
                )
            if config.ocr_region is not None:
                region_left, region_top, region_width, region_height = config.ocr_region
                if (
                    region_width < 10 or region_height < 10
                    or region_left < left or region_top < top
                    or region_left + region_width > left + width
                    or region_top + region_height > top + height
                ):
                    raise ValueError(f"{config.name}: the OCR region is outside the current screen.")
            range_values = [item.value for item in config.approved_ranges]
            if len(range_values) != len(set(range_values)):
                raise ValueError(f"{config.name}: approved time ranges must be unique.")
            for value in range_values:
                if parse_time_range(value) != value:
                    raise ValueError(f"{config.name}: invalid approved time range {value!r}.")
        try:
            multiplier = float(self.multiplier.get())
        except ValueError as exc:
            raise ValueError("Global speed multiplier must be a number greater than zero.") from exc
        if not math.isfinite(multiplier) or multiplier <= 0:
            raise ValueError("Global speed multiplier must be a finite number greater than zero.")
        for config in configs:
            if config.enabled and not math.isfinite(config.interval_ms / multiplier / 1000):
                raise ValueError(
                    f"{config.name}: effective interval is too large for this multiplier."
                )
        try:
            touch_spacing = float(self.touch_spacing.get())
        except ValueError as exc:
            raise ValueError("Touch gap must be a number from 0 to 1000 ms.") from exc
        if not math.isfinite(touch_spacing) or not 0 <= touch_spacing <= 1000:
            raise ValueError("Touch gap must be a finite number from 0 to 1000 ms.")
        try:
            touch_hold = float(self.touch_hold.get())
        except ValueError as exc:
            raise ValueError("Touch hold must be a number from 10 to 1000 ms.") from exc
        if not math.isfinite(touch_hold) or not 10 <= touch_hold <= 1000:
            raise ValueError("Touch hold must be a finite number from 10 to 1000 ms.")
        return configs, multiplier, touch_spacing, touch_hold

    def toggle(self):
        if self.scheduler.snapshot()[0]:
            self.stop()
        else:
            self.start()

    def start(self):
        try:
            configs, multiplier, touch_spacing, touch_hold = self.collect_configs()
            input_mode = self.input_mode.get()
            self.ocr_monitor.stop()
            self.scheduler.start(
                configs, multiplier, input_mode, touch_spacing, touch_hold,
                self.cycle_tabs.get(),
            )
            if self.time_filter_enabled.get():
                self.ocr_results.clear()
                for config in configs:
                    self.ocr_status_tree.item(
                        config.id,
                        values=(config.name, "—", "UNKNOWN", "Waiting for OCR"),
                        tags=("unknown",),
                    )
                self.ocr_monitor.start(configs)
        except (ValueError, RuntimeError) as exc:
            messagebox.showerror("Cannot start clickers", str(exc), parent=self.root)
            return
        self.status.set("RUNNING")
        self.timing.set(
            f"Running in {input_mode} mode at {multiplier:g}x. Effective intervals are never below 10 ms; "
            "actual delivery depends on Windows scheduling and system load. "
            + ("Ctrl+Tab is sent to the foreground app after each complete round. " if self.cycle_tabs.get() else "")
            + ("Passive OCR status monitoring is active; it does not gate clicks. " if self.time_filter_enabled.get() else "")
            + "Settings changed now apply on the next start."
        )

    def stop(self):
        try:
            self.scheduler.stop()
        except RuntimeError as exc:
            messagebox.showerror("Stop error", str(exc), parent=self.root)
        try:
            self.ocr_monitor.stop()
        except RuntimeError as exc:
            messagebox.showerror("OCR monitor stop error", str(exc), parent=self.root)
        self.status.set("STOPPED")
        self.timing.set("Stopped. Windows scheduling is best-effort; minimum interval is 10 ms.")

    def select_position(self, row):
        if self.overlay is not None:
            return
        self.selected_row = row
        left, top, width, height = virtual_screen()
        overlay = Toplevel(self.root)
        overlay.overrideredirect(True)
        overlay.attributes("-topmost", True)
        overlay.attributes("-alpha", 0.30)
        overlay.geometry(f"{width}x{height}+{left}+{top}")
        overlay.configure(background="#18324a")
        self.overlay = overlay
        label = ttk.Label(
            overlay,
            text=f"Click the desired screen position for {row.name.get()}  ·  Esc to cancel",
            font=("Segoe UI", 18, "bold"),
            padding=20,
        )
        label.place(relx=0.5, rely=0.08, anchor="n")
        overlay.bind("<Button-1>", self.capture_position)
        overlay.bind("<Escape>", lambda _event: self.cancel_position())
        label.bind("<Button-1>", self.capture_position)
        overlay.focus_force()

    def capture_position(self, _event):
        point = POINT()
        if not user32.GetCursorPos(ctypes.byref(point)):
            messagebox.showerror("Position unavailable", "Windows could not read the cursor position.")
            self.cancel_position()
            return
        self.selected_row.x.set(str(point.x))
        self.selected_row.y.set(str(point.y))
        self.cancel_position()

    def cancel_position(self):
        if self.overlay is not None:
            self.overlay.destroy()
        self.overlay = None
        self.selected_row = None

    def save_config(self):
        try:
            configs, multiplier, touch_spacing, touch_hold = self.collect_configs()
        except ValueError as exc:
            messagebox.showerror("Invalid configuration", str(exc), parent=self.root)
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Save clicker configuration",
            defaultextension=".json",
            filetypes=(("JSON configuration", "*.json"),),
        )
        if not path:
            return
        payload = {
            "version": 1,
            "multiplier": multiplier,
            "input_mode": self.input_mode.get(),
            "touch_spacing_ms": touch_spacing,
            "touch_hold_ms": touch_hold,
            "cycle_tabs": self.cycle_tabs.get(),
            "time_filter_enabled": self.time_filter_enabled.get(),
            "clickers": [asdict(item) for item in configs],
        }
        try:
            with open(path, "w", encoding="utf-8") as file:
                json.dump(payload, file, indent=2)
        except OSError as exc:
            messagebox.showerror("Save failed", str(exc), parent=self.root)

    def load_config(self):
        if self.status.get() == "RUNNING":
            messagebox.showwarning("Stop first", "Stop all clickers before loading a configuration.")
            return
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Load clicker configuration",
            filetypes=(("JSON configuration", "*.json"),),
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = json.load(file)
            if not isinstance(payload, dict) or payload.get("version") != 1 or not isinstance(payload.get("clickers"), list):
                raise ValueError("Unsupported or malformed configuration file.")
            configs = []
            for raw_item in payload["clickers"]:
                if not isinstance(raw_item, dict):
                    raise ValueError("Each clicker configuration must be an object.")
                item_data = raw_item.copy()
                raw_region = item_data.get("ocr_region")
                if raw_region is not None:
                    if (
                        not isinstance(raw_region, (list, tuple))
                        or len(raw_region) != 4
                        or any(
                            not isinstance(value, int) or isinstance(value, bool)
                            for value in raw_region
                        )
                    ):
                        raise ValueError("OCR regions must contain four integer values.")
                    item_data["ocr_region"] = tuple(raw_region)
                raw_ranges = item_data.get("approved_ranges", [])
                if not isinstance(raw_ranges, list):
                    raise ValueError("Approved time ranges must be a list.")
                ranges = []
                for raw_range in raw_ranges:
                    if (
                        not isinstance(raw_range, dict)
                        or not isinstance(raw_range.get("value"), str)
                        or not isinstance(raw_range.get("enabled", True), bool)
                    ):
                        raise ValueError("Each approved time range must have text and an enabled flag.")
                    normalized = parse_time_range(raw_range["value"])
                    if normalized is None or normalized != raw_range["value"]:
                        raise ValueError(f"Invalid approved time range: {raw_range['value']!r}.")
                    ranges.append(
                        ApprovedTimeRange(normalized, raw_range.get("enabled", True))
                    )
                item_data["approved_ranges"] = ranges
                configs.append(ClickerConfig(**item_data))
            multiplier = float(payload["multiplier"])
            if not math.isfinite(multiplier) or multiplier <= 0:
                raise ValueError("The saved speed multiplier must be greater than zero.")
            input_mode = payload.get("input_mode", "Mouse")
            if input_mode not in ("Mouse", "Touch"):
                raise ValueError("The saved input mode must be Mouse or Touch.")
            touch_spacing = payload.get("touch_spacing_ms", 25)
            if (
                not isinstance(touch_spacing, (int, float))
                or isinstance(touch_spacing, bool)
                or not math.isfinite(float(touch_spacing))
                or not 0 <= touch_spacing <= 1000
            ):
                raise ValueError("The saved touch gap must be a number from 0 to 1000 ms.")
            touch_hold = payload.get("touch_hold_ms", 30)
            if (
                not isinstance(touch_hold, (int, float))
                or isinstance(touch_hold, bool)
                or not math.isfinite(float(touch_hold))
                or not 10 <= touch_hold <= 1000
            ):
                raise ValueError("The saved touch hold must be a number from 10 to 1000 ms.")
            cycle_tabs = payload.get("cycle_tabs", False)
            if not isinstance(cycle_tabs, bool):
                raise ValueError("The saved tab cycling setting must be true or false.")
            time_filter_enabled = payload.get("time_filter_enabled", False)
            if not isinstance(time_filter_enabled, bool):
                raise ValueError("The saved time-filter setting must be true or false.")
            ids = [item.id for item in configs]
            if len(ids) != len(set(ids)) or any(not item_id for item_id in ids):
                raise ValueError("Clicker IDs must be present and unique.")
            for item in configs:
                if item.ocr_region is not None and (
                    len(item.ocr_region) != 4
                    or item.ocr_region[2] < 10
                    or item.ocr_region[3] < 10
                ):
                    raise ValueError(f"Invalid OCR region in {item.name}.")
                range_values = [time_range.value for time_range in item.approved_ranges]
                if len(range_values) != len(set(range_values)):
                    raise ValueError(f"Duplicate approved time ranges in {item.name}.")
                if (
                    not isinstance(item.id, str)
                    or not isinstance(item.name, str)
                    or not item.name.strip()
                    or not isinstance(item.enabled, bool)
                    or not isinstance(item.x, int)
                    or isinstance(item.x, bool)
                    or not isinstance(item.y, int)
                    or isinstance(item.y, bool)
                    or not isinstance(item.click_limit, int)
                    or isinstance(item.click_limit, bool)
                    or not isinstance(item.interval_ms, (int, float))
                    or isinstance(item.interval_ms, bool)
                    or not math.isfinite(float(item.interval_ms))
                    or item.interval_ms < 10
                    or item.click_limit < 0
                    or not isinstance(item.initial_delay_ms, (int, float))
                    or isinstance(item.initial_delay_ms, bool)
                    or not math.isfinite(float(item.initial_delay_ms))
                    or item.initial_delay_ms < 0
                ):
                    raise ValueError(f"Invalid settings in {item.name or 'unnamed clicker'}.")
                if item.button not in ("Left", "Right", "Middle"):
                    raise ValueError(f"Invalid mouse button in {item.name}.")
            if not configs:
                raise ValueError("The configuration contains no clickers.")
        except (OSError, json.JSONDecodeError, TypeError, KeyError, ValueError) as exc:
            messagebox.showerror("Load failed", str(exc), parent=self.root)
            return
        for row in self.rows:
            row.frame.destroy()
        self.rows.clear()
        self.multiplier.set(str(multiplier))
        self.input_mode.set(input_mode)
        self.touch_spacing.set(str(touch_spacing))
        self.touch_hold.set(str(touch_hold))
        self.cycle_tabs.set(cycle_tabs)
        self.time_filter_enabled.set(time_filter_enabled)
        for config in configs:
            self.add_clicker(config)

    def poll(self):
        try:
            while True:
                event, detail = self.events.get_nowait()
                if event == "ocr_result":
                    clicker_id, status, detected, description, timestamp = detail
                    self.ocr_results[clicker_id] = (
                        status, detected, description, timestamp
                    )
                    row = next(
                        (candidate for candidate in self.rows if candidate.config_id == clicker_id),
                        None,
                    )
                    if self.ocr_status_tree.exists(clicker_id):
                        self.ocr_status_tree.item(
                            clicker_id,
                            values=(row.name.get() if row is not None else "", detected or "—", status, description),
                            tags=(status.lower(),),
                        )
                elif event == "toggle":
                    self.toggle()
                elif event == "hotkey_ready":
                    self.hotkey_state.set("F8: global start/stop")
                elif event == "hotkey_error":
                    self.hotkey_state.set("F8 unavailable")
                    messagebox.showerror(
                        "Global hotkey unavailable",
                        f"Windows could not register F8: {detail}\nUse the Start / Stop button instead.",
                        parent=self.root,
                    )
                elif event == "error":
                    self.status.set("STOPPED")
                    self.timing.set("Stopped safely after an input error.")
                    messagebox.showerror("Clicking stopped", detail, parent=self.root)
        except queue.Empty:
            pass

        running, results, late_count = self.scheduler.snapshot()
        if not running and self.status.get() == "RUNNING":
            self.status.set("STOPPED")
            try:
                self.ocr_monitor.stop()
            except RuntimeError as exc:
                messagebox.showerror("OCR monitor stop error", str(exc), parent=self.root)
        for row in self.rows:
            row.update_status(results.get(row.config_id))
            ocr_result = self.ocr_results.get(row.config_id)
            if ocr_result is not None:
                ocr_status, detected, description, timestamp = ocr_result
                if time.monotonic() - timestamp > OCR_RESULT_MAX_AGE_SECONDS:
                    if self.ocr_status_tree.exists(row.config_id):
                        self.ocr_status_tree.item(
                            row.config_id,
                            values=(row.name.get(), "—", "UNKNOWN", "OCR result is stale"),
                            tags=("unknown",),
                        )
        if running and late_count:
            self.timing.set(
                f"Timing warning: {late_count} delayed dispatch(es). Windows scheduling and system load "
                "may prevent the requested cadence."
            )
        self.update_summary()
        self.root.after(50, self.poll)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self.cancel_position()
        self.cancel_ocr_region()
        try:
            self.scheduler.stop()
        finally:
            try:
                self.ocr_monitor.stop()
            finally:
                try:
                    self.hotkey_listener.close()
                finally:
                    self.root.destroy()

    def report_callback_exception(self, exception_type, exception, exception_traceback):
        try:
            self.scheduler.stop()
        finally:
            self.ocr_monitor.stop()
        self.status.set("STOPPED")
        self.timing.set("Stopped safely after an application error.")
        details = "".join(traceback.format_exception(exception_type, exception, exception_traceback))
        messagebox.showerror(
            "Application error",
            f"All clicking has been stopped because the interface encountered an error.\n\n{details}",
            parent=self.root,
        )


def main():
    set_dpi_awareness()
    root = Tk()
    app = ClickerApp(root)
    try:
        root.mainloop()
    finally:
        app.close()


if __name__ == "__main__":
    main()
